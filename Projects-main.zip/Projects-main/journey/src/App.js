import React, { useState } from "react";
import "./App.css";

const FormInput = () => {
  const dropdownStyle = {
    width: "100%",
    height: "2.5rem",
    borderRadius: "4px",
  };

  const [source, setSource] = useState("");
  const [destination, setDestination] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const handleSourceChange = (e) => {
    const selectedSource = e.target.value;
    setSource(selectedSource);
    validateSelections(selectedSource, destination);
  };

  const handleDestinationChange = (e) => {
    const selectedDestination = e.target.value;
    setDestination(selectedDestination);
    validateSelections(source, selectedDestination);
  };

  const validateSelections = (selectedSource, selectedDestination) => {
    if (selectedSource === selectedDestination) {
      setErrorMessage("Source and destination cannot be the same.");
    } else {
      setErrorMessage("");
    }
  };

  return (
    <div className="container">
      <form className="form">
        <div className="form-title">
          <span>Wonder into the</span>
        </div>
        <div className="title-2">
          <span>SPACE</span>
        </div>
        <div className="input-container">
          <select
            className="input-mail"
            style={dropdownStyle}
            value={source}
            onChange={handleSourceChange}
          >
            <option value="">Select Source</option>
            <option value="Mars">Mars</option>
            <option value="Mercury">Mercury</option>
            <option value="Venus">Venus</option>
            <option value="Earth">Earth</option>
            <option value="Jupiter">Jupiter</option>
            <option value="Moon">Moon</option>
            <option value="Saturn">Saturn</option>
            <option value="Neptune">Neptune</option>
            {/* Add more planet options as needed */}
          </select>
        </div>

        <section className="bg-stars">
          <span className="star"></span>
          <span className="star"></span>
          <span className="star"></span>
          <span className="star"></span>
        </section>

        <div className="input-container">
          <select
            className="input-pwd"
            style={dropdownStyle}
            value={destination}
            onChange={handleDestinationChange}
          >
            <option value="">Select Destination</option>
            <option value="Mars">Mars</option>
            <option value="Mercury">Mercury</option>
            <option value="Venus">Venus</option>
            <option value="Earth">Earth</option>
            <option value="Jupiter">Jupiter</option>
            <option value="Moon">Moon</option>
            <option value="Saturn">Saturn</option>
            <option value="Neptune">Neptune</option>
            {/* Add more planet options as needed */}
          </select>
        </div>
        {errorMessage && <p style={{ color: "red" }}>{errorMessage}</p>}
        <button
          type="submit"
          className="submit"
          disabled={source === "" || destination === "" || errorMessage !== ""}
        >
          <span className="sign-text">Start</span>
        </button>
      </form>
      <div className="white-div left-div"></div>
      <div className="white-div right-div"></div>
    </div>
  );
};

export default FormInput;
